import pkg from '@aws-sdk/client-dynamodb';
const { DynamoDBClient, PutCommand } = pkg;
// import { DynamoDBClient, PutCommand } from "@aws-sdk/client-dynamodb";
// import { nanoid } from "./nanoid";
import { nanoid } from "nanoid";

const client = new DynamoDBClient({region: "us-east-2"});
const dynamoDBTable = "AppTable";
const s3Bucket = "ContentStorage";

export const handler = async (event) => {
    const id = nanoid();
    const requestBody = JSON.parse(event.body);
    const { textInput, fileName } = requestBody;

    const params = {
        TableName: dynamoDBTable,
        Item: {
          id: { S: id },
          textInput: { S: textInput },
          fileName: { S: fileName },
        },
      };
    try {
    //   await dynamoDB.put(params).promise();
      await client.send(new PutCommand(params));
      const response = {
        statusCode: 200,
        body: JSON.stringify({ message: 'Item successfully written to DynamoDB', item }),
      };
      return response;
    } catch (error) {
      console.error('Error writing to DynamoDB', error);
      const response = {
        statusCode: 500,
        body: JSON.stringify({ message: 'Failed to write to DynamoDB', error }),
      }
      return response;
    }
};
  